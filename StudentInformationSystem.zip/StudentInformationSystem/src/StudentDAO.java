import java.sql.*;
import java.util.*;

public class StudentDAO {
    
   public void addStudent(Student student) {
     
        String sql = "INSERT INTO students (first_name, last_name, age, email) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setInt(3, student.getAge());
            stmt.setString(4, student.getEmail());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
   public List<Student> getAllStudents() {
    List<Student> students = new ArrayList<>();
    String sql = "SELECT * FROM students";

    try (Connection conn = DBConnection.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            Student s = new Student();
            s.setStudentId(rs.getInt("student_id"));
            s.setFirstName(rs.getString("first_name"));
            s.setLastName(rs.getString("last_name"));
            s.setAge(rs.getInt("age"));
            s.setEmail(rs.getString("email"));

            students.add(s);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return students;
}
   
   public void updateStudent(Student student) {
    String sql = "UPDATE students SET first_name=?, last_name=?, age=?, email=? WHERE student_id=?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, student.getFirstName());
        stmt.setString(2, student.getLastName());
        stmt.setInt(3, student.getAge());
        stmt.setString(4, student.getEmail());
        stmt.setInt(5, student.getStudentId());

        stmt.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}
   
   public void deleteStudent(int id) {
       System.out.println("Delete clicked");
    String sql = "DELETE FROM students WHERE student_id=?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, id);
        stmt.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}
   
   
   
   
}
